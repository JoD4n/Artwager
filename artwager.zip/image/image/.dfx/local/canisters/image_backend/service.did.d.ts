import type { Principal } from '@dfinity/principal';
import type { ActorMethod } from '@dfinity/agent';

export interface _SERVICE {
  'checkBalance' : ActorMethod<[], bigint>,
  'joinContest' : ActorMethod<[bigint], undefined>,
  'topup' : ActorMethod<[bigint], undefined>,
  'withdraw' : ActorMethod<[bigint], undefined>,
}
