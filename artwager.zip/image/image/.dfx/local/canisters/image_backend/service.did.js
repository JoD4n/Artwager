export const idlFactory = ({ IDL }) => {
  return IDL.Service({
    'checkBalance' : IDL.Func([], [IDL.Int], []),
    'joinContest' : IDL.Func([IDL.Int], [], ['oneway']),
    'topup' : IDL.Func([IDL.Int], [], ['oneway']),
    'withdraw' : IDL.Func([IDL.Int], [], ['oneway']),
  });
};
export const init = ({ IDL }) => { return []; };
