import { image_backend } from "../../declarations/image_backend";


document.getElementById("join").addEventListener("click",async function() {
  var balance = await image_backend.joinContest(BigInt(2));
  document.getElementById("popup").style.display = "none";
  document.getElementById("stauts").innerText = "You've joined the contest";
});
document.getElementById("deposit").addEventListener("click",async function() {
  var depositamount = document.getElementById("amount-debit").value;
  var balance = await image_backend.topup(BigInt(depositamount));
});
window.addEventListener("load", async function(){
  console.log("finished");
  const currentBalance = await image_backend.checkBalance();
  document.getElementById("value").innerText = currentBalance;
});
document.getElementById("join-button").addEventListener("click",function() {
  document.getElementById("popup").style.display = "block";
});
document.getElementById("create-button").addEventListener("click",function() {
  document.getElementById("inputField").style.display = "block";
});
document.getElementById("posted-button").addEventListener("click",function() {
  const description = document.getElementById("description");
  const amount = document.getElementById("amount");
  document.getElementById("job-title").innerText = "Logo Design";
  document.getElementById("create-button").innerText = "Join";
  document.getElementById("inputField").style.display = "none";
});

document.getElementById("close-button").addEventListener("click",function() {
  document.getElementById("popup").style.display = "none";
});


document.getElementById("join").addEventListener("click",async function() {
  const balance = await image_backend.joinContest(BigInt(2));
  document.getElementById("popup").style.display = "none";
  document.getElementById("stauts").innerText = "You've joined the contest";
});

window.addEventListener("load", async function(){
  console.log("finished");
  const currentBalance = await image_backend.checkBalance();
  document.getElementById("value").innerText = currentBalance;
});
document.getElementById("join-button").addEventListener("click",function() {
  document.getElementById("popup").style.display = "block";
});
document.getElementById("close-button").addEventListener("click",function() {
  document.getElementById("popup").style.display = "none";
});


const table = document.getElementById('leaderboard-table');
    const rows = table.getElementsByTagName('tr');
    
    for (let i = 1; i < rows.length; i++) {
      rows[i].addEventListener('mouseover', function() {
        this.style.backgroundColor = '#FDD878';
      });
      
      rows[i].addEventListener('mouseout', function() {
        this.style.backgroundColor = i % 2 === 0 ? '#FFFFE0' : '#FEEFBC';
      });
    }
document.getElementById("closebutton").addEventListener("click",function() {
  document.getElementById("inputField").style.display = "none";
});
